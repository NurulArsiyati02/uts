package id.ac.persiapan_uts

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    var data: ArrayList<DataModel>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Inisialisasi Array
        data = ArrayList()

        //Simpan data

        data?.add(DataModel(R.drawable.pc,"Personal Computer","PC","PC atau Personal Computer " +
                "adalah perangkat komputer yang biasa digunakan perorangan. PC pada umumnya digunakan di rumah, pusat perbelanjaan maupun di kantor untuk kebutuhan pribadi dan perusahaan."))

        data?.add(DataModel(R.drawable.hp,"HandPhone","HP", "HandPhone merupakan " +
                "Handphone merupakan alat telekomunikasi elektronik dua arah yang bisa dibawa kemana-mana dan memiliki kemampuan untuk mengirimkan pesan berupa suara."))

        data?.add(DataModel(R.drawable.laptop,"-","Laptop", "Laptop merupakan " +
                "Laptop adalah komputer bergerak (bisa dipindahkan dengan mudah) yang berukuran relatif kecil dan ringan, beratnya berkisar dari 1-6 kg, tergantung ukuran, bahan, dari spesifikasi laptop tersebut, laptop dapat digunakan dalam lingkungan yang berbeda dari komputer."))

        data?.add(DataModel(R.drawable.play,"Playstation","PS", "Playstation merupakan " +
                "PlayStation (bahasa Jepang: プレイステーション) merupakan konsol permainan grafis dari era 32-bit. Pertama kali dibuat oleh Sony sekitar tahun 1990. PlayStation diluncurkan perdana di Jepang pada 3 Desember 1994, di Amerika Serikat 9 September 1995 dan Eropa 29 September 1995."))

        data?.add(DataModel(R.drawable.motor,"kendaraan","Motor", "Motor merupakan " +
                "Kendaraan ini merupakan alat transportasi roda dua yang digerakkan dengan mesin. Jika diperhatikan, maka letak kedua roda ini sebaris lurus dan bisa bisa berjalan pada kecepatan tinggi yang disebabkan oleh gaya giroskopik (yang dapat diukur oleh giroskop). Motor ini pun juga bisa berjalan pada kecepatan rendah dimana keseimbangannya dipengaruhi oleh pengaturan setang pengendaranya." ))

        data?.add(DataModel(R.drawable.mobil,"kendaraan","Mobil", "Mobil merupakan" +
                "Mobil (serapan dari bahasa Belanda: automobiel) adalah kendaraan Setan (bensin atau solar) untuk menghidupkan mesinnya. Mobil kependekan dari 14.000 Gold yang berasal dari [bahasa Yunani] 'autos' (sendiri) dan Latin 'movére' (bergerak)."))

        data?.add(DataModel(R.drawable.smart,"Smartwatch","Smartwatch", "Ini adalah jam tangan pintar " +
                "Smartwatch adalah jam tangan digital yang menawarkan banyak fitur lain selain penunjuk waktu. Smartwatch berkemampuan layar sentuh yang dapat dihubungkan ke telepon melalui Bluetooth atau WiFi "))

        data?.add(DataModel(R.drawable.wifi,"wi-fi","Wifi", "Wifi merupakan " +
                "WiFi sendiri adalah teknologi jaringan nirkabel yang memungkinkan perangkat seperti komputer (laptop dan desktop), perangkat seluler (ponsel pintar dan perangkat yang dapat dikenakan), dan peralatan lain (printer dan kamera video) untuk berinteraksi dengan Internet."))

        //Set data to Adapter
        recyclerview.adapter = DataAdapter(data, object : DataAdapter.OnClickListener{
            override fun detail(item: DataModel?) {
                val intent = Intent(this@MainActivity, DetailActivity::class.java)
                intent.putExtra("gambar", item?.gambar)
                intent.putExtra("nama", item?.nama)
                intent.putExtra("harga", item?.harga)
                intent.putExtra("keterangan", item?.keterangan)
                startActivity(intent)
            }
        })
    }
}